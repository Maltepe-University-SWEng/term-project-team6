﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using JokeGeneratorBackend.Data;
using JokeGeneratorBackend.Models;

namespace JokeGeneratorBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class JokesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public JokesController(AppDbContext context)
        {
            _context = context;
        }

        // POST: api/jokes
        [HttpPost]
        public async Task<IActionResult> AddJoke([FromBody] Joke joke)
        {
            var userExists = await _context.Users.AnyAsync(u => u.UserId == joke.UserId);
            if (!userExists)
                return NotFound("User not found.");

            joke.CreatedAt = DateTime.Now;

            _context.Jokes.Add(joke);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Joke added successfully", joke.JokeId });
        }

        // GET: api/jokes/1
        [HttpGet("{userId}")]
        public async Task<IActionResult> GetJokesByUser(int userId)
        {
            var jokes = await _context.Jokes
                .Where(j => j.UserId == userId)
                .ToListAsync();

            return Ok(jokes);
        }
    }
}
