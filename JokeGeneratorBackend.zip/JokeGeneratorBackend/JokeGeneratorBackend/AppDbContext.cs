﻿using Microsoft.EntityFrameworkCore;
using JokeGeneratorBackend.Models;
using System.Collections.Generic;


namespace JokeGeneratorBackend.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Joke> Jokes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasKey(u => u.UserId);
            modelBuilder.Entity<Joke>().HasKey(j => j.JokeId);

            modelBuilder.Entity<Joke>()
                .HasOne(j => j.User)
                .WithMany(u => u.Jokes)
                .HasForeignKey(j => j.UserId);
        }
    }
}
